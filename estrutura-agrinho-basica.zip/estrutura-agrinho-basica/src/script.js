let frases = [
  "Preservar é garantir o futuro 🌱",
  "Agricultura e natureza podem viver juntas",
  "Economizar água é essencial",
  "O campo sustentável é o futuro"
];

let i = 0;

function trocarFrase(){

  document.getElementById("frase").innerHTML = frases[i];

  i++;

  if(i >= frases.length){
    i = 0;
  }

}

/* TROCA DE FUNDO */

function fundoVerde(){

  document.body.style.backgroundImage =
  "url('https://images.unsplash.com/photo-1501004318641-b39e6451bec6')";

}

function fundoClaro(){

  document.body.style.backgroundImage =
  "url('https://images.unsplash.com/photo-1523741543316-beb7fc7023d8')";

}

function fundoAgricola(){

  document.body.style.backgroundImage =
  "url('https://images.unsplash.com/photo-1464226184884-fa280b87c399')";

}